<template>
  <div class="container">
    <div class="row">

      <CreatUser />


      <div v-for="user in allUsers" :key="user.id" class="col-lg-4 col-md-6 mt-10">
        <div class="card h-100">
          <div class="card-header h-100">
            User information number {{ user.id }}
          </div>
          <ul class="list-group list-group-flush h-100">
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">name :</span> {{ user.name }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">father's name :</span> {{ user.company.name }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">user name :</span> {{ user.username }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">Phone :</span> {{ user.phone }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">email :</span> {{ user.email }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">birthday id :</span> {{ user.address.zipcode }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">city :</span> {{ user.address.city }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">street :</span> {{ user.address.street }}</li>
          </ul>

          <div class="card-footer">
            <Delete :id="user.id" :user="user" />
          </div>


        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import CreatUser from "@/components/CreatUser";
import Delete from "@/components/Update";

export default {
  name: "Users",
  components: { Delete, CreatUser },
  computed: {
    ...mapGetters({
      allUsers: 'user/allUsers'
    })
  },
  mounted() {
    this.$store.dispatch('user/fetchUsers')
  }
};
</script>

<style scoped>

</style>
