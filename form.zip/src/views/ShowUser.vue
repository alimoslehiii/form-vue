<template>
  <div class="container">
    <div class="row">
      <div class="col-md-10 mt-8 offset-1">
        <div class="card">
          <div class="card-header">
            User information number {{ user.id }}
          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">name :</span> {{ user.name }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">father's name :</span> {{ user.company.name }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">user name :</span> {{ user.username }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">Phone :</span> {{ user.phone }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">email :</span> {{ user.email }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">birthday id :</span> {{ user.address.zipcode }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">city :</span> {{ user.address.city }}</li>
            <li class="list-group-item"><span class="font-weight-bold text-uppercase">street :</span> {{ user.address.street }}</li>
          </ul>

          <div class="card-footer">
            <router-link :to="{ name: 'edit-user', params: { id: user.id }}" type="button" class="btn btn-warning text-light">Edit</router-link>
          </div>

        </div>
      </div>

    </div>
  </div>
</template>

<script>
export default {
  name: "ShowUser",
  computed: {
    user(){
      return this.$store.getters["user/allUsers"].find(user => user.id == this.$route.params.id)
    }
  },
};
</script>

<style scoped>

</style>
